import 'package:flutter/material.dart';

class Profile extends StatelessWidget {
  const Profile({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 135, 90, 120),
        title: const Text('Profile Developer')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Nama Developer: Anggi Selawati"),
            Text("NPM: 2210020104"),
            Text("Kelas: 5A NONREG SI BJM"),
            Text("Kontak: 085219303057"),
            Text("Alamat: Tanah Bumbu"),
          ],
        ),
      ),
    );
  }
}
