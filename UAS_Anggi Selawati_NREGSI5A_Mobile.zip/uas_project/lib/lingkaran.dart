import 'package:flutter/material.dart';

class Lingkaran extends StatefulWidget{
  const Lingkaran({super.key});
  @override
  _Lingkaranstate createState() => _Lingkaranstate();
}

class _Lingkaranstate extends State<Lingkaran>{
  final TextEditingController _jariController = TextEditingController();

  String _result = '';

  void _hitung(){
    //Mengambil input dari TextEditingControllers
    double? jari = double.tryParse(_jariController.text);

    //Memeriksa apakah input valid
    if (jari != null){
      setState(() {
        _result = '';//Mengosongkan hasil sebelumnya
        
        _result = 'Luas = ${3.14*jari*jari} cm2';
      });
    } else {
      setState(() {
        _result = 'Input tidak valid. Mohon masukkan angka.';
      });
    }
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 135, 90, 120),
        title: Text('Aplikasi Perhitungan Lingkaran')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            //input angka pertama
            TextField(
              controller: _jariController,
              decoration: InputDecoration(labelText: 'Masukkan Jari-jari (cm):'),
              keyboardType: TextInputType.number,
            ),
            //tombol untuk menghitung
            ElevatedButton(
              onPressed: _hitung, 
              child: Text('Hitung Luas')),
            //Menampilkan hasil
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Text(
                _result,
              style: TextStyle(fontSize: 20),),) 
          ],
        ),
      ),
    );
  }
}