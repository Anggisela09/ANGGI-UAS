import 'package:flutter/material.dart';
import 'package:uas_project/lingkaran.dart';
import 'package:uas_project/persegi.dart';
import 'package:uas_project/profile.dart';

class Dashboard extends StatefulWidget{
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard>{
  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: const Text('Proyek UAS Pemrograman Mobile'),
        backgroundColor: Color.fromARGB(255, 135, 90, 120),
      ),
      body: Container(
        height: 200,
        width: double.infinity,
        margin: const EdgeInsets.all(20),
        padding: const EdgeInsets.all(30),
        child: Column(
          children: [
            ElevatedButton(
              onPressed: (){
                Navigator.push(context, 
                MaterialPageRoute(builder: (context) => Persegi()));
              },
              child: Text('HITUNG LUAS PERSEGI\nPilih Untuk Mulai Menghitung Luas Persegi'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: (){
                Navigator.push(context, 
                MaterialPageRoute(builder: (context) => Lingkaran()));
              },
              child: Text('HITUNG LUAS LINGKARAN\nPilih Untuk Mulai Menghitung Luas Lingkaran'),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: (){
                Navigator.push(context, 
                MaterialPageRoute(builder: (context) => Profile()));
              },
              child: Text('PROFILE DEVELOPER\nPilih Untuk Melihat Developer'),
            )
          ],
        )
      )
    );
  }
}