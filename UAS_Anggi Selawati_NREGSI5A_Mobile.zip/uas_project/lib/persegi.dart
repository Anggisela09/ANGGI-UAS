import 'package:flutter/material.dart';

class Persegi extends StatefulWidget{
  const Persegi({super.key});
  @override
  _Persegistate createState() => _Persegistate();
}

class _Persegistate extends State<Persegi>{
  final TextEditingController _sisiController = TextEditingController();

  String _result = '';

  void _hitung(){
    //Mengambil input dari TextEditingControllers
    double? sisi = double.tryParse(_sisiController.text);

    //Memeriksa apakah input valid
    if (sisi != null){
      setState(() {
        _result = '';//Mengosongkan hasil sebelumnya
        
        _result = 'Luas = ${sisi*sisi} cm2';
      });
    } else {
      setState(() {
        _result = 'Input tidak valid. Mohon masukkan angka.';
      });
    }
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 135, 90, 120),
        title: Text('Aplikasi Perhitungan Persegi')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            //input angka pertama
            TextField(
              controller: _sisiController,
              decoration: InputDecoration(labelText: 'Masukkan Sisi (cm):'),
              keyboardType: TextInputType.number,
            ),
            //tombol untuk menghitung
            ElevatedButton(
              onPressed: _hitung, 
              child: Text('Hitung Luas')),
            //Menampilkan hasil
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Text(
                _result,
              style: TextStyle(fontSize: 20),),) 
          ],
        ),
      ),
    );
  }
}